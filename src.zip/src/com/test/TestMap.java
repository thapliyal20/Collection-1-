//HashMap

package com.test;

import java.util.Collection;
import java.util.HashMap;

public class TestMap {

	public static void main(String[] args) 
	{
		HashMap<Integer,Employee>	map;
		map=new HashMap<Integer,Employee>();
		Employee e1 = new Employee(2001, "Kritika", 9000);
		Employee e2 = new Employee(3001, "Vikrant", 8000);
		Employee e3 = new Employee(1001, "Saavi", 6000);
		
		map.put(1001,e3);
		map.put(2001,e1);
		map.put(3001,e2);
		
		//if(map.containsKey(2002))					//EMPLOYEE NOT FOUND
		if(map.containsKey(2001))					//output will come
		{
			//Employee emp=map.get(2002);
			Employee emp=map.get(2001);
			System.out.println(emp);
		}
		else
		{
			System.out.println("*************EMPLOYEE NOT FOUND*************");
		}
		
		Collection<Employee> collection = map.values();   //output(if use this line only) : Employee [employeeId=2001, empName=Kritika, empSal=9000]
		
		System.out.println("--------------------------------------------------");
		
		collection.forEach(p->System.out.println(p));	  /*output(if use this line only) : Employee [employeeId=2001, empName=Kritika, empSal=9000]
																							//Employee [employeeId=1001, empName=Saavi, empSal=6000]
																							Employee [employeeId=3001, empName=Vikrant, empSal=8000] */

	}

}
