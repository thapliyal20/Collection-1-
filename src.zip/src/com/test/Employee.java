package com.test;

public class Employee implements Comparable {				//to compare implement Comparable

	private int employeeId;
	private String empName;
	private int empSal;

	public Employee(int employeeId, String empName, int empSal) {
		super();
		this.employeeId = employeeId;
		this.empName = empName;
		this.empSal = empSal;
	}

	public Employee() {
		super();
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpSal() {
		return empSal;
	}

	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}

	
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", empName=" + empName
				+ ", empSal=" + empSal + "]";
	}

	@Override
	public int compareTo(Object obj) {
		Employee emp= ( Employee ) obj;
		//int n=this.employeeId - emp.employeeId;			//compared on the basis of employeeId
		int n=this.empName.compareTo(emp.empName);			//instead of using 53 logic use this to compare
		return n;
		
	}
	
	

}
