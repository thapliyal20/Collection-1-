//Collections- sorted (for sorting)
			   //shuffle (for shuffling)

package com.test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;
import java.util.Vector;

public class TestCollection3 {
	
	
	
	
	public static void main(String[] args) {
			
		//ArrayList list=new ArrayList();			//List list=new ArrayList();  (it will work without Array also)	
		//List list=new ArrayList();
		//Collection list=new LinkedList();			//For LinkedList
		//Collection list=new HashSet();				//For HashSet
		//Collection list=new TreeSet();				//Order of insertion & retrieval is same
		List list=new ArrayList();				
		
		
		list.add(10);
		list.add(100);
		list.add(30);
		list.add(6);
		//Collections.sort(list);				//first added and then sorted the list
		Collections.shuffle(list);				//for shuffling
		//list.add(1,"Grapes");				//1 means grapes will be added after Orange(1)					
		
		
		
	
		
		for(Object obj : list )
		{
			//String str=(String) obj;
			System.out.println(obj);		//grapes is not there so out is true		//for duplicacy it will give false
			//System.out.println(list.add("Apple"));	//False as duplicacy is there
		}
			System.out.println("---------------------------");
			Iterator iterator=list.iterator();
			
			while(iterator.hasNext())
			{
				Object obj= iterator.next();
				System.out.println(obj);
				
				System.out.println("..........................");
				
			}
		
			list.forEach(p-> System.out.println(p));
		
		
		
		
		
		/*
		list.clear();
		int n= list.size();
		System.out.println(" Size :" +n);
		//Object obj=list.get(2);
		String obj=(String)list.get(2);			//by explicit typecasting we can use (String)
		//String obj=list.get(2);    			//wrong that's why pt. 21
		System.out.println( obj );
		*/
	}
}
