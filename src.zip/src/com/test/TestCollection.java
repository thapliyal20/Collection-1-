package com.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TestCollection {
	
	
	
	
	public static void main(String[] args) {
			
		//ArrayList list=new ArrayList();			//List list=new ArrayList();  (it will work without Array also)	
		List list=new ArrayList();
		//Collection list=new ArrayList();		//will not work and if we want to add we can't add that's why List
		list.add("Orange");
		list.add("Apple");
		list.add("Banana");
		list.add(1,"Grapes");				//1 means grapes will be added after Orange(1)					
		
		for(int i=0; i<list.size(); i++)
		{
			System.out.println( list.get(i));
		}
		System.out.println("******************************");
		
		
	
		
		for(Object obj : list )
		{
			//String str=(String) obj;
			System.out.println(obj);
		}
			System.out.println("---------------------------");
			Iterator iterator=list.iterator();
			
			while(iterator.hasNext())
			{
				Object obj= iterator.next();
				System.out.println(obj);
				
				System.out.println("..........................");
				
			}
		
			list.forEach(p-> System.out.println(p));
		
		
		
		
		
		/*
		list.clear();
		int n= list.size();
		System.out.println(" Size :" +n);
		//Object obj=list.get(2);
		String obj=(String)list.get(2);			//by explicit typecasting we can use (String)
		//String obj=list.get(2);    			//wrong that's why pt. 21
		System.out.println( obj );
		*/
	}
}
