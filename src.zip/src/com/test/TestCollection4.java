package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestCollection4 {

	public static void main(String[] args) {

		//List list = new ArrayList();
		//Set list = new TreeSet(new EmployeeComparator());		//for sorting in Set			
		Set<Employee> list = new TreeSet<Employee>(new EmployeeComparator());	
		Employee e1 = new Employee(2001, "Kritika", 9000);
		Employee e2 = new Employee(3001, "Vikrant", 8000);
		Employee e3 = new Employee(1001, "Saavi", 6000);

		list.add(e1);
		list.add(e2);
		list.add(e3);		
		//Collections.sort(list);
		//Collections.sort(list,new EmployeeComparator());			//take the id from list and will compare in Employee Comparator code //(Collections used in List not in Set)

		for (Object obj : list) {
			Employee emp = (Employee) obj;				//type casting for only getting employee name
			//System.out.println(emp.getEmpName());		//only name will display
			System.out.println(emp);
		}
	}
}